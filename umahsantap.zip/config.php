<?php
// Konfigurasi Database
define('DB_HOST', 'sql113.byethost33.com');
define('DB_USER', 'b33_40011306'); // Sesuaikan dengan username database Anda
define('DB_PASS', 'mrslcn122009'); // Sesuaikan dengan password database Anda
define('DB_NAME', 'b33_40011306_umahsantap');

// Membuat Koneksi
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek Koneksi
if ($conn->connect_error) {
    die("Koneksi Gagal: " . $conn->connect_error);
}

// Pengaturan Dasar Aplikasi
define('BASE_URL', 'http://localhost/umahsantap/');

// Mulai Session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Fungsi Bantuan (jika diperlukan)
function format_rupiah($angka){
    $hasil_rupiah = "Rp " . number_format($angka,0,',','.');
    return $hasil_rupiah;
}
?>