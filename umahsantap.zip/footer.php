</div> <!-- /container -->

<footer class="py-4 bg-dark text-white-50 mt-auto">
    <div class="container text-center">
        <small>Copyright &copy; Umah Santap 2025</small>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
